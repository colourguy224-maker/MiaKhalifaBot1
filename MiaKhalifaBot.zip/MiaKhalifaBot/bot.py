import logging, random, asyncio, shelve
from datetime import datetime, time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

# ================= CONFIG =================
BOT_TOKEN = "7866222277:AAHcGI4FutB7sQ6ooCtk5FoCObgpL00T5o4"
ADMIN_ID = 6317553959
CHANNEL_LINK = "https://t.me/Mia_KhalifaKa_kotha"
LOG_GROUP = -1002401153604
DB_FILE = "userdata.db"
VIDEO_DB = "videos.db"
BOT_USERNAME = "MiaKhalifaKakotha_bot"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ================= DATABASE =================
def get_user_data(user_id):
    with shelve.open(DB_FILE) as db:
        if str(user_id) not in db:
            db[str(user_id)] = {
                "name": "", "username": "", "joined": False,
                "premium": False, "daily_limit": 3,
                "referrals": 0, "join_date": str(datetime.now().date())
            }
        return db[str(user_id)]

def save_user_data(user_id, data):
    with shelve.open(DB_FILE, writeback=True) as db:
        db[str(user_id)] = data

def all_users():
    with shelve.open(DB_FILE) as db:
        return db

def add_video(file_id):
    with shelve.open(VIDEO_DB, writeback=True) as db:
        vids = db.get("list", [])
        vids.append(file_id)
        db["list"] = vids

def get_videos():
    with shelve.open(VIDEO_DB) as db:
        return db.get("list", [])

def remove_video(file_id):
    with shelve.open(VIDEO_DB, writeback=True) as db:
        vids = db.get("list", [])
        if file_id in vids:
            vids.remove(file_id)

# ================= LOGGING =================
async def log_action(context: ContextTypes.DEFAULT_TYPE, message):
    try:
        await context.bot.send_message(LOG_GROUP, message)
    except:
        pass

# ================= DAILY RESET =================
async def daily_reset(context: ContextTypes.DEFAULT_TYPE):
    with shelve.open(DB_FILE, writeback=True) as db:
        for uid in db:
            if not db[uid]["premium"]:
                db[uid]["daily_limit"] = 3
    await log_action(context, "✅ Daily limit reset for all free users.")

# ================= START =================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    data = get_user_data(user.id)
    data["name"] = user.first_name
    data["username"] = f"@{user.username}" if user.username else "❌"
    save_user_data(user.id, data)
    await log_action(context, f"👤 {user.first_name} ({user.id}) started the bot.")

    keyboard = [
        [InlineKeyboardButton("📢 Join Channel", url=CHANNEL_LINK)],
        [InlineKeyboardButton("✅ Confirm Joined", callback_data="jointed")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(f"👋 Hello {user.first_name}!\nYour ID: {user.id}\nWelcome to our channel!", reply_markup=reply_markup)

# ================= JOINTED =================
async def jointed_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    await query.answer()
    data = get_user_data(user.id)
    data["joined"] = True
    save_user_data(user.id, data)
    await log_action(context, f"✅ {user.first_name} ({user.id}) confirmed joined.")
    await query.message.delete()

    keyboard = [
        [KeyboardButton("🎥 Get Video"), KeyboardButton("⭐ Buy Premium")],
        [KeyboardButton("📊 Plan Status"), KeyboardButton("📩 Support")],
        [KeyboardButton("🔗 Referral")]
    ]
    if user.id == ADMIN_ID:
        keyboard.append([KeyboardButton("🛠 Admin Panel")])
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await query.message.reply_text(
        f"🎉 Mubarak ho {user.first_name}! Menu unlocked 👇",
        reply_markup=reply_markup
    )

# ================= USER MENU =================
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    data = get_user_data(user.id)
    text = update.message.text

    if text == "🎥 Get Video":
        vids = get_videos()
        if not vids:
            await update.message.reply_text("⚠️ No videos available.")
            return
        if data["premium"] or data["daily_limit"] > 0:
            video = random.choice(vids)
            if not data["premium"]:
                data["daily_limit"] -= 1
                save_user_data(user.id, data)
            msg = await update.message.reply_video(video, caption="⚠️ Yah video 10 minut bad delete ho jaega copyright ki vajah se")
            await log_action(context, f"🎥 {user.first_name} ({user.id}) got video {video}")
            await asyncio.sleep(600)
            try:
                await context.bot.delete_message(chat_id=update.message.chat_id, message_id=msg.message_id)
            except:
                pass
        else:
            keyboard = [[InlineKeyboardButton("📩 Contact Admin", url=f"tg://user?id={ADMIN_ID}")]]
            await update.message.reply_text("❌ Your daily limit has expired. Contact admin to buy premium.",
                                            reply_markup=InlineKeyboardMarkup(keyboard))

    elif text == "⭐ Buy Premium":
        keyboard = [[InlineKeyboardButton("📩 Contact Admin", url=f"tg://user?id={ADMIN_ID}")]]
        await update.message.reply_text(
            "💎 Premium Plans:\n1 week → ₹99\n1 month → ₹400\nBenefits: Daily 200 videos\nContact admin to buy premium",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        await log_action(context, f"⭐ {user.first_name} ({user.id}) checked premium info.")

    elif text == "📊 Plan Status":
        referral_link = f"https://t.me/{BOT_USERNAME}?start={user.id}"
        msg = (f"👤 Name: {data['name']}\n"
               f"🆔 ID: {user.id}\n"
               f"⭐ Premium: {'Yes' if data['premium'] else 'No'}\n"
               f"🎥 Daily Limit Left: {data['daily_limit']}\n"
               f"👥 Referrals: {data['referrals']}\n"
               f"🔗 Referral Link: {referral_link}\n"
               f"📅 Join Date: {data['join_date']}")
        await update.message.reply_text(msg)

    elif text == "📩 Support":
        keyboard = [
            [InlineKeyboardButton("📩 Direct Admin DM", url=f"tg://user?id={ADMIN_ID}")],
            [InlineKeyboardButton("🔗 Support Channel", url=CHANNEL_LINK)]
        ]
        await update.message.reply_text(
            "Bhai agar kuchh bhi problem ho to jaldi admin ko report karo",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif text == "🔗 Referral":
        referral_link = f"https://t.me/{BOT_USERNAME}?start={user.id}"
        await update.message.reply_text(f"Your referral link:\n{referral_link}\nShare and earn +10 videos per referral!")

    elif text == "🛠 Admin Panel" and user.id == ADMIN_ID:
        keyboard = [
            [InlineKeyboardButton("📤 Bulk Upload Video", callback_data="upload_video")],
            [InlineKeyboardButton("🗑 Remove Video", callback_data="remove_video")],
            [InlineKeyboardButton("👥 User List", callback_data="user_list")],
            [InlineKeyboardButton("📢 Broadcast", callback_data="broadcast")],
            [InlineKeyboardButton("💎 Give Premium", callback_data="give_premium")],
            [InlineKeyboardButton("🎬 Total Video List", callback_data="video_list")]
        ]
        await update.message.reply_text("🛠 Admin Panel:", reply_markup=InlineKeyboardMarkup(keyboard))

# ================= ADMIN PANEL CALLBACK =================
async def admin_panel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    if user.id != ADMIN_ID:
        await query.message.edit_text("❌ You are not admin!")
        return

    if query.data == "user_list":
        db = all_users()
        text = "👥 Users:\n"
        for k, v in db.items():
            text += f"{v['name']} ({k}) - {'Premium' if v['premium'] else 'Free'}, Join Date: {v['join_date']}, Referrals: {v['referrals']}\n"
        await query.message.edit_text(text)

    elif query.data == "video_list":
        vids = get_videos()
        if vids:
            text = "🎬 Total Videos:\n" + "\n".join(vids)
        else:
            text = "⚠️ No videos uploaded yet."
        await query.message.edit_text(text)

# ================= VIDEO UPLOAD =================
async def handle_video_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id == ADMIN_ID and update.message.video:
        file_id = update.message.video.file_id
        add_video(file_id)
        await update.message.reply_text(f"✅ Video saved!\nFileID: {file_id}")
        await log_action(context, f"📤 Admin uploaded video {file_id}")

# ================= MAIN =================
def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(jointed_callback, pattern="^jointed$"))
    app.add_handler(CallbackQueryHandler(admin_panel_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.VIDEO, handle_video_upload))
    app.job_queue.run_daily(daily_reset, time=time(0,0,0))
    app.run_polling()

if __name__ == "__main__":
    main()
    